^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package autoware_lanelet2_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.13.0 (2019-12-03)
-------------------
* Update package.xml of autoware_lanelet2_msgs for release.
* Rename lanelet2_msgs to autoware_lanelet2_msgs
* Contributors: Joshua Whitley, Kenji Miyake
